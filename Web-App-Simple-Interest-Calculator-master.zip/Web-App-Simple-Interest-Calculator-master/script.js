const slider = document.getElementById("slider");
const value = document.getElementById("value");
const date = new Date().getFullYear();

value.innerHTML = `${slider.value}%`;
slider.oninput = function()
{ 
    value.innerHTML = `${this.value}%`;
}

function calc()
{
  let y = document.getElementById("year").value;
  return y;
}

function compute()
{
  const p = parseFloat(document.getElementById("principal").value);
  const r = parseFloat(document.getElementById("slider").value);
  const Total_amount = (p*r/100*calc());
  const dates = +date + +calc();
if(p>0)
document.getElementById("result").innerHTML=(`If you deposit <span class="color">${p}</span>,<br>at an interest rate of <span class="color">${r}</span>.<br>You will receive an amount of <span class="color">${Total_amount}</span>,<br>in the year <span class="color">${dates}</span>`);
else if (p<=0) 
{
alert("Please Enter a positive number!");
document.getElementById("principal").focus();
return;
}
else
alert("Please Enter any positive number!");
document.getElementById("principal").focus();
return;
}